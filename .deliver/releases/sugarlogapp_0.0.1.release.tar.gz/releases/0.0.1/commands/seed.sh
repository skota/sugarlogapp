#!/bin/bash

release_ctl eval --mfa "MyApp.ReleaseTasks.seed/1" -- "$@"